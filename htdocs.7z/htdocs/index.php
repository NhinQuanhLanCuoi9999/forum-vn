<?php
session_start();
include('config.php');

// Kiểm tra nếu người dùng đã đăng nhập thông qua cookie
if (isset($_COOKIE['username']) && !isset($_SESSION['username'])) {
    $_SESSION['username'] = $_COOKIE['username'];
}

// Đăng ký
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $checkUser = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $checkUser->bind_param("s", $username);
    $checkUser->execute();
    $result = $checkUser->get_result();

    if ($result->num_rows > 0) {
        $error = "Tài khoản đã tồn tại!";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $success = "Đăng ký thành công!";
    }

    // Chuyển hướng về trang đăng nhập hoặc trang chính để ngăn việc gửi form lặp lại
    header("Location: index.php");
    exit();
}

// Đăng nhập
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $username;

            // Thiết lập cookie để ghi nhớ người dùng trong 30 ngày
            setcookie("username", $username, time() + (30 * 24 * 60 * 60), "/"); // 30 ngày

            // Chuyển hướng sau khi đăng nhập
            header("Location: index.php");
            exit();
        } else {
            $error = "Mật khẩu không chính xác!";
        }
    } else {
        $error = "Tài khoản không tồn tại!";
    }
}

// Đăng bài
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['post'])) {
    $content = $_POST['content'];
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];

    // Lưu ảnh vào thư mục uploads
    if ($image) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($image);
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
    }

    // Đăng bài
    $stmt = $conn->prepare("INSERT INTO posts (content, description, image, username) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $content, $description, $image, $_SESSION['username']);
    $stmt->execute();

    // Chuyển hướng sau khi đăng bài để ngăn việc gửi form lặp lại
    header("Location: index.php");
    exit(); // Dừng xử lý thêm mã
}

// Xóa bài viết
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Kiểm tra xem người dùng có phải là chủ bài viết
    $stmt = $conn->prepare("SELECT * FROM posts WHERE id = ? AND username = ?");
    $stmt->bind_param("is", $id, $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Nếu là chủ bài viết, tiến hành xóa
        $stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    } else {
        $error = "Bạn không có quyền xóa bài viết này!";
    }

    // Chuyển hướng để làm mới trang
    header("Location: index.php");
    exit();
}

// Thêm bình luận
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comment'])) {
    $post_id = $_POST['post_id'];
    $content = $_POST['content'];

    $stmt = $conn->prepare("INSERT INTO comments (post_id, content, username) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $post_id, $content, $_SESSION['username']);
    $stmt->execute();

    // Chuyển hướng sau khi bình luận để ngăn việc gửi form lặp lại
    header("Location: index.php");
    exit();
}

// Xóa bình luận
if (isset($_GET['delete_comment'])) {
    $comment_id = $_GET['delete_comment'];
    $stmt = $conn->prepare("DELETE FROM comments WHERE id = ? AND username = ?");
    $stmt->bind_param("is", $comment_id, $_SESSION['username']);
    $stmt->execute();

    // Chuyển hướng để làm mới trang
    header("Location: index.php");
    exit();
}

// Lấy danh sách bài viết
$posts = $conn->query("SELECT * FROM posts ORDER BY created_at DESC");

// Đăng xuất
if (isset($_GET['logout'])) {
    // Xóa cookie
    setcookie("username", "", time() - 3600, "/"); // Xóa cookie
    session_unset();
    session_destroy();
    header("Location: index.php"); // Chuyển hướng về trang chính
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h1, h2 {
            color: #333;
        }

        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }

        form {
            background: #fff;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        input[type="text"],
        input[type="password"],
        textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            background: #5cb85c;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #4cae4c;
        }

        .error {
            color: red;
            margin: 10px 0;
        }

        .success {
            color: green;
            margin: 10px 0;
        }

        .post {
            background: #fff;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .comment {
            background: #f9f9f9;
            padding: 5px;
            margin: 5px 0;
            border-radius: 3px;
        }

        #register-form, #login-form {
            display: none;
        }

        .toggle-link {
            color: blue;
            cursor: pointer;
            text-decoration: underline;
        }

        .no-posts {
            font-style: italic;
            color: #666;
        }

        .lg {
            transform: translate(100px, -560px);
        }
.logout-button {
    background-color: #d9534f;
    color: white;
    transform: translate(100px, -360px);
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-left: 20px;
}

.logout-button:hover {
    background-color: #c9302c;
}
    </style>
    <script>
        function toggleForms() {
            const loginForm = document.getElementById('login-form');
            const registerForm = document.getElementById('register-form');
            
            // Toggle the display of the forms
            if (loginForm.style.display === 'none') {
                loginForm.style.display = 'block';
                registerForm.style.display = 'none';
            } else {
                loginForm.style.display = 'none';
                registerForm.style.display = 'block';
            }
        }
    </script>
    <script>
    let isFormFocused = false;
    let isFormFilled = false;

    // Kiểm tra khi form đang được focus (đang có con trỏ trong form)
    document.addEventListener('focusin', function (event) {
        if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
            isFormFocused = true;
        }
    });

    // Kiểm tra khi form không còn được focus
    document.addEventListener('focusout', function (event) {
        if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
            isFormFocused = false;
        }
    });

    // Kiểm tra nếu form đã có ký tự
    document.addEventListener('input', function (event) {
        const inputs = document.querySelectorAll('input[type="text"], textarea');
        isFormFilled = Array.from(inputs).some(input => input.value.trim() !== '');
    });

    // Refresh trang mỗi 5 giây, trừ khi đang nhập liệu
    setInterval(function () {
        if (!isFormFocused && !isFormFilled) {
            location.reload();
        }
    }, 5000); // 5000 milliseconds = 5 seconds
</script>
</head>
<body>
    <div class="container">
        <h1>Forum</h1>

        <?php if (!isset($_SESSION['username'])): ?>
            <!-- Hiển thị form nếu chưa đăng nhập -->
            <form id="login-form" method="post" action="index.php" style="display: block;">
                <h2>Đăng nhập</h2>
                <input type="text" name="username" placeholder="Tên đăng nhập" required>
                <input type="password" name="password" placeholder="Mật khẩu" required>
                <button type="submit" name="login">Đăng nhập</button>
                <p>Chưa có tài khoản? <span class="toggle-link" onclick="toggleForms()">Đăng ký</span></p>
            </form>

            <form id="register-form" method="post" action="index.php" style="display: none;">
                <h2>Đăng ký</h2>
                <input type="text" name="username" placeholder="Tên đăng nhập" required>
                <input type="password" name="password" placeholder="Mật khẩu" required>
                <button type="submit" name="register">Đăng ký</button>
                <p>Đã có tài khoản? <span class="toggle-link" onclick="toggleForms()">Đăng nhập</span></p>
            </form>

            <?php if (isset($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            <?php if (isset($success)): ?>
                <div class="success"><?php echo $success; ?></div>
            <?php endif; ?>

        <?php else: ?>
            <!-- Hiển thị form đăng bài nếu đã đăng nhập -->
         <form method="post" action="index.php" enctype="multipart/form-data">
                <h2>Đăng bài viết</h2>
                <textarea name="content" placeholder="Nội dung bài viết (Lưu ý : Chỉ khi không nhập gì vào form thì post người khác mới cập nhật.)" required></textarea>
                <input type="text" name="description" placeholder="Mô tả ngắn" required>
                <input type="file" name="image">
                <button type="submit" name="post">Đăng bài</button>
            </form>
 <a href="index.php?logout=true">
        <button class="logout-button">Đăng xuất</button>
    </a>
   <h2>Các bài viết</h2>
            <?php if ($posts->num_rows > 0): ?>
                <?php while ($post = $posts->fetch_assoc()): ?>
                    <div class="post">
                        <h3><?php echo htmlspecialchars($post['content']); ?></h3>
                        <p><?php echo htmlspecialchars($post['description']); ?></p>
                        <?php if ($post['image']): ?>
                            <img src="uploads/<?php echo htmlspecialchars($post['image']); ?>" alt="Image" style="max-width: 100%; height: auto;">
                        <?php endif; ?>
                        <small>Đăng bởi: <?php echo htmlspecialchars($post['username']); ?> vào <?php echo $post['created_at']; ?></small>
                        <?php if ($post['username'] == $_SESSION['username']): ?>
                            <a href="index.php?delete=<?php echo $post['id']; ?>">Xóa bài viết</a>
                        <?php endif; ?>

                        <form method="post" action="index.php">
                            <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                            <textarea name="content" placeholder="Bình luận" required></textarea>
                            <button type="submit" name="comment">Gửi bình luận</button>
                        </form>

                        <h4>Bình luận:</h4>
                        <?php
                        $post_id = $post['id'];
                        $comments = $conn->query("SELECT * FROM comments WHERE post_id = $post_id ORDER BY created_at DESC");
                        if ($comments->num_rows > 0):
                            while ($comment = $comments->fetch_assoc()):
                        ?>
                                <div class="comment">
                                    <strong><?php echo htmlspecialchars($comment['username']); ?>:</strong>
                                    <?php echo htmlspecialchars($comment['content']); ?>
                                    <?php if ($comment['username'] == $_SESSION['username']): ?>
                                        <a href="index.php?delete_comment=<?php echo $comment['id']; ?>">Xóa bình luận</a>
                                    <?php endif; ?>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="no-posts">Chưa có bình luận nào.</p>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="no-posts">Chưa có bài viết nào.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>