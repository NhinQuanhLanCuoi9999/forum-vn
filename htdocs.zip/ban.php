<?php
session_start();
include('config.php');

// Kiểm tra xem người dùng có phải là admin không
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header("Location: index.php"); // Chuyển hướng nếu không phải admin
    exit();
}

// Đường dẫn tệp log
$log_file = 'logs/ban-log.txt';

// Hàm ghi log
function writeLog($message) {
    global $log_file;
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($log_file, "[$timestamp] $message\n", FILE_APPEND);
}

// Thêm người dùng vào danh sách cấm
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ban'])) {
    $username = $_POST['username']; // Tên người dùng (có thể để trống)
    $reason = $_POST['reason'];
    $ban_duration = $_POST['ban_duration']; // thời gian cấm (số ngày)
    $ip_address = $_POST['ip_address']; // Nếu bạn muốn cấm IP

    $ban_end = date('Y-m-d H:i:s', strtotime("+$ban_duration days"));
    $permanent = 0; // Cấm tạm thời (có thể thay đổi theo nhu cầu)

    if (!empty($username)) {
        // Lấy user_id từ bảng users
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $user_id = $user['id'];

            // Thêm vào cơ sở dữ liệu
            $stmt = $conn->prepare("INSERT INTO bans (username, ip_address, reason, ban_start, ban_end, permanent) VALUES (?, ?, ?, NOW(), ?, ?)");
            $stmt->bind_param("ssssi", $username, $ip_address, $reason, $ban_end, $permanent);
            $stmt->execute();

            // Ghi log
            writeLog("Cấm người dùng: $username, Lý do: $reason, Đến: $ban_end, IP: $ip_address");
        } else {
            echo "<script>alert('Không tìm thấy người dùng!');</script>";
        }
    } elseif (!empty($ip_address)) {
        // Nếu chỉ cấm bằng IP
        $stmt = $conn->prepare("INSERT INTO bans (username, ip_address, reason, ban_start, ban_end, permanent) VALUES (?, ?, ?, NOW(), ?, ?)");
        $username = 'IP_Censored'; // Đặt tên người dùng thành 'IP_Censored' hoặc giá trị mặc định khác
        $stmt->bind_param("ssssi", $username, $ip_address, $reason, $ban_end, $permanent);
        $stmt->execute();

        // Ghi log
        writeLog("Cấm IP: $ip_address, Lý do: $reason, Đến: $ban_end");
    } else {
        echo "<script>alert('Vui lòng nhập tên người dùng hoặc địa chỉ IP để cấm!');</script>";
    }
}

// Xóa lệnh cấm
if (isset($_GET['unban'])) {
    $ban_id = $_GET['unban'];
    $stmt = $conn->prepare("DELETE FROM bans WHERE id = ?");
    $stmt->bind_param("i", $ban_id);
    $stmt->execute();

    // Ghi log
    writeLog("Hủy cấm ID: $ban_id");
}

// Lấy danh sách cấm
$bans = $conn->query("SELECT bans.*, users.username FROM bans LEFT JOIN users ON bans.username = users.username");

// Hiển thị danh sách cấm
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý lệnh cấm</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            color: #343a40;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #dc3545;
        }
        h2 {
            color: #495057;
        }
        form {
            margin-bottom: 20px;
        }
        input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ced4da;
            border-radius: 5px;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .ban-list {
            margin-top: 20px;
            border-top: 1px solid #ced4da;
            padding-top: 10px;
        }
        .ban-item {
            padding: 10px;
            border-bottom: 1px solid #dee2e6;
        }
        .ban-item:last-child {
            border-bottom: none;
        }
        .unban-link {
            color: #dc3545;
            text-decoration: none;
        }
        .unban-link:hover {
            text-decoration: underline;
        }
           .redirect-button {
            background-color: #007bff; /* Màu nền */
            color: white; /* Màu chữ */
            border: none; /* Không viền */
            border-radius: 5px; /* Bo góc */
            padding: 8px 15px; /* Khoảng cách bên trong */
            font-size: 16px; /* Kích thước chữ */
            cursor: pointer; /* Hiệu ứng con trỏ */
            transition: background-color 0.3s; /* Hiệu ứng chuyển màu */
            transform: translate(100px, 100px);
        }

        .redirect-button:hover {
            background-color: #0056b3; /* Màu nền khi hover */
        }
    </style>
</head>
<body>
  <button class="redirect-button" onclick="window.location.href='admin.php'">Quay lại </button>
    <div class="container">
        <h1>Quản lý lệnh cấm</h1>
        <form method="POST">
            <input type="text" name="username" placeholder="Tên người dùng (có thể để trống)">
            <input type="text" name="ip_address" placeholder="IP muốn cấm">
            <textarea name="reason" placeholder="Lý do cấm" required></textarea>
            <input type="number" name="ban_duration" placeholder="Thời gian cấm (ngày)" required>
            <input type="submit" name="ban" value="Cấm">
        </form>

        <h2>Danh sách người dùng bị cấm</h2>
        <div class="ban-list">
            <?php while ($ban = $bans->fetch_assoc()): ?>
                <div class="ban-item">
                    <p>Người dùng: <?php echo htmlspecialchars($ban['username'] ?? 'N/A'); ?> - IP: <?php echo htmlspecialchars($ban['ip_address']); ?> - Lý do: <?php echo htmlspecialchars($ban['reason']); ?> - Đến: <?php echo htmlspecialchars($ban['ban_end']); ?> 
                    <a class="unban-link" href="ban.php?unban=<?php echo $ban['id']; ?>">Hủy cấm</a></p>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>