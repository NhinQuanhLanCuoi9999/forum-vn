<?php
session_start();
include('config.php');

// Kiểm tra nếu người dùng đã đăng nhập thông qua cookie
if (isset($_COOKIE['username']) && !isset($_SESSION['username'])) {
    $_SESSION['username'] = $_COOKIE['username'];
}

// Hàm ghi log
function logAction($action) {
    $ip = $_SERVER['REMOTE_ADDR'];
    $username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Khách';
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] - IP: $ip - Người dùng: $username - Hành động: $action\n";

    // Ghi log vào file logs.txt
    file_put_contents('logs.txt', $log_entry, FILE_APPEND);
}

// Hàm định dạng nội dung
function formatText($text) {
    // Định dạng chữ in đậm
    $text = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $text); // **text**
    
    // Định dạng chữ lớn (in đậm)
    $text = preg_replace('/##(.*?)##/', '<strong style="font-size: 1.5em;">$1</strong>', $text); // ##text##
    
    // Định dạng chữ gạch ngang
    $text = preg_replace('/--(.*?)--/', '<del>$1</del>', $text); // --text--

    return $text;
}

// Đăng ký
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Kiểm tra nếu hai mật khẩu không trùng khớp
    if ($password !== $confirm_password) {
        $_SESSION['error'] = "Hai mật khẩu không trùng khớp!";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $checkUser = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $checkUser->bind_param("s", $username);
        $checkUser->execute();
        $result = $checkUser->get_result();

        if ($result->num_rows > 0) {
            $_SESSION['error'] = "Tài khoản đã tồn tại!";
        } else {
            $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $hashed_password);
            $stmt->execute();
            $_SESSION['success'] = "Đăng ký thành công!";
            logAction("Đăng ký tài khoản: $username");
        }
    }

    // Chỉ chuyển hướng nếu không có lỗi
    if (!isset($_SESSION['error']) && !isset($_SESSION['success'])) {
        header("Location: index.php");
        exit();
    }
}

// Đăng nhập
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $username;

            // Thiết lập cookie để ghi nhớ người dùng trong 30 ngày
            setcookie("username", $username, time() + (30 * 24 * 60 * 60), "/");
            logAction("Đăng nhập thành công: $username");

            // Chuyển hướng sau khi đăng nhập
            header("Location: index.php");
            exit();
        } else {
            $error = "Mật khẩu không chính xác!";
        }
    } else {
        $error = "Tài khoản không tồn tại!";
    }
}

// Đăng bài
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['post'])) {
    $content = $_POST['content'];
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];

    // Lưu ảnh vào thư mục uploads
    if ($image) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($image);
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
    }

    // Đăng bài
    $stmt = $conn->prepare("INSERT INTO posts (content, description, image, username) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $content, $description, $image, $_SESSION['username']);
    $stmt->execute();
    logAction("Đăng bài mới của người dùng: {$_SESSION['username']}");

    // Chuyển hướng sau khi đăng bài để ngăn việc gửi form lặp lại
    header("Location: index.php");
    exit();
}

// Xóa bài viết
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Kiểm tra xem người dùng có phải là chủ bài viết
    $stmt = $conn->prepare("SELECT * FROM posts WHERE id = ? AND username = ?");
    $stmt->bind_param("is", $id, $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Nếu là chủ bài viết, tiến hành xóa
        $stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        logAction("Xóa bài viết với ID: $id bởi người dùng: {$_SESSION['username']}");
    } else {
        $error = "Bạn không có quyền xóa bài viết này!";
    }

    // Chuyển hướng để làm mới trang
    header("Location: index.php");
    exit();
}

// Thêm bình luận
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comment'])) {
    $post_id = $_POST['post_id'];
    $content = $_POST['content'];

    // Định dạng nội dung bình luận
    $formatted_content = formatText($content);

    $stmt = $conn->prepare("INSERT INTO comments (post_id, content, username) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $post_id, $formatted_content, $_SESSION['username']);
    $stmt->execute();
    logAction("Thêm bình luận vào bài viết ID: $post_id bởi người dùng: {$_SESSION['username']}");

    // Chuyển hướng sau khi bình luận để ngăn việc gửi form lặp lại
    header("Location: index.php");
    exit();
}

// Xóa bình luận
if (isset($_GET['delete_comment'])) {
    $comment_id = $_GET['delete_comment'];
    $stmt = $conn->prepare("DELETE FROM comments WHERE id = ? AND username = ?");
    $stmt->bind_param("is", $comment_id, $_SESSION['username']);
    $stmt->execute();
    logAction("Xóa bình luận ID: $comment_id bởi người dùng: {$_SESSION['username']}");

    // Chuyển hướng để làm mới trang
    header("Location: index.php");
    exit();
}

// Lấy danh sách bài viết
$posts = $conn->query("SELECT * FROM posts ORDER BY created_at DESC");

// Đăng xuất
if (isset($_GET['logout'])) {
    // Xóa cookie
    setcookie("username", "", time() - 3600, "/");
    session_unset();
    session_destroy();
    logAction("Đăng xuất: {$_SESSION['username']}");
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <style>
        body {
    font-family: Arial, sans-serif;
    background: linear-gradient(90deg, azure, lightblue); /* Hiệu ứng gradient từ màu azure sang màu lightblue */
    margin: 0;
    padding: 0;
}

        h1, h2 {
            color: #333;
        }

        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }

        form {
            background: #fff;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        input[type="text"],
        input[type="password"],
        textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            background: #5cb85c;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #4cae4c;
        }

        .error {
            color: red;
            margin: 10px 0;
        }

        .success {
            color: green;
            margin: 10px 0;
        }

.post {
    background: linear-gradient(to bottom right, #cce5ff, #99ccff); /* Gradient từ màu xanh nhạt đến màu xanh đậm hơn */
    padding: 10px;
    margin: 10px 0;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
}

        .comment {
    background: linear-gradient(to bottom right, #fff2cc, #ffe6b3); /* Gradient từ màu vàng nhạt đến vàng nhạt hơn */
    padding: 5px;
    margin: 5px 0;
    border-radius: 3px;
}

        #register-form, #login-form {
            display: none;
        }

        .toggle-link {
            color: blue;
            cursor: pointer;
            text-decoration: underline;
        }

        .no-posts {
            font-style: italic;
            color: #666;
        }
.delete-button {
    background-color: red; /* Màu nền đỏ */
    color: white; /* Màu chữ trắng */
    border: none; /* Không có viền */
    outline: none; /* Không có viền ngoài */
    padding: 10px 20px; /* Khoảng cách bên trong nút */
    font-size: 16px; /* Kích thước chữ */
    cursor: pointer; /* Hiển thị con trỏ chuột khi di chuột qua nút */
    border-radius: 5px; /* Bo góc cho nút */
    transition: background-color 0.3s; /* Hiệu ứng chuyển đổi màu nền */
}

.delete-button:hover {
    background-color: darkred; /* Màu nền khi di chuột qua nút */
}        .lg {
            transform: translate(100px, -560px);
        }
.logout-button {
    background-color: #d9534f;
    color: white;
    transform: translate(100px, -360px);
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-left: 20px;
}

.logout-button:hover {
    background-color: #c9302c;
}
        /* Style cho thông báo che phủ toàn bộ màn hình */
        #mobile-warning 
        {
            display: none; /* Bắt đầu với trạng thái ẩn */
            position: fixed; /* Đặt vị trí cố định */
            top: 0;
            left: 0;
            right: 0;
            bottom: 0; /* Phủ kín toàn bộ chiều cao */
            background: rgba(255, 0, 0, 1); /* Nền đỏ hoàn toàn không trong suốt */
            color: white; /* Màu chữ trắng */
            text-align: center; /* Canh giữa văn bản */
            padding-top: 20%; /* Đưa thông báo xuống giữa */
            font-size: 24px; /* Kích thước chữ */
            z-index: 1000; /* Đảm bảo thông báo ở trên cùng */
        }

        /* Ngăn cuộn trang */
        body.no-scroll {
            overflow: hidden; /* Ngăn không cho cuộn */
        }
    </style>
    <script>
        function toggleForms() {
            const loginForm = document.getElementById('login-form');
            const registerForm = document.getElementById('register-form');
            
            // Toggle the display of the forms
            if (loginForm.style.display === 'none') {
                loginForm.style.display = 'block';
                registerForm.style.display = 'none';
            } else {
                loginForm.style.display = 'none';
                registerForm.style.display = 'block';
            }
        }
    </script>
  <script>
    let isFormFocused = false;
let isFormFilled = false;
let isRefreshing = true;

function toggleForms() {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    
    // Toggle the display of the forms
    if (loginForm.style.display === 'none') {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
    } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
    }
}

// Không làm mới trang khi quét khối
document.addEventListener('selectionchange', () => {
    if (document.getSelection().toString()) {
        isRefreshing = false; // Ngừng refresh khi có lựa chọn
    } else {
        isRefreshing = true; // Bắt đầu refresh lại khi không có lựa chọn
    }
});

// Biến http:// hoặc https:// thành liên kết
document.addEventListener('DOMContentLoaded', () => {
    const posts = document.querySelectorAll('.post');
    posts.forEach(post => {
        const content = post.querySelector('h3');
        content.innerHTML = convertLinks(content.innerHTML);
    });
});

function convertLinks(text) {
    return text.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank">$1</a>');
}

// Kiểm tra khi form đang được focus (đang có con trỏ trong form)
document.addEventListener('focusin', function (event) {
    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
        isFormFocused = true;
    }
});

// Kiểm tra khi form không còn được focus
document.addEventListener('focusout', function (event) {
    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
        isFormFocused = false;
    }
});

// Kiểm tra nếu form đã có ký tự
document.addEventListener('input', function (event) {
    const inputs = document.querySelectorAll('input[type="text"], textarea');
    isFormFilled = Array.from(inputs).some(input => input.value.trim() !== '');
});

// Refresh trang mỗi 5 giây, trừ khi đang nhập liệu
setInterval(function () {
    if (isRefreshing && !isFormFocused && !isFormFilled) {
        location.reload();
    }
}, 5000); // 5000 milliseconds = 5 seconds
</script>
</head>
<body>
    <div id="mobile-warning">
        Vui lòng bật chế độ xem trên máy tính
    </div>

    <script>
        // Kiểm tra kích thước màn hình
        function checkScreenSize() {
            const warning = document.getElementById('mobile-warning');
            if (window.innerWidth < 768) { // Nếu màn hình nhỏ hơn 768px
                warning.style.display = 'flex'; // Hiện thông báo
                document.body.classList.add('no-scroll'); // Ngăn cuộn trang
            } else {
                warning.style.display = 'none'; // Ẩn thông báo
                document.body.classList.remove('no-scroll'); // Cho phép cuộn trang
            }
        }

        // Gọi hàm khi trang được tải, khi kích thước màn hình thay đổi,
        // và khi thay đổi hướng màn hình
        window.onload = checkScreenSize;
        window.onresize = checkScreenSize;
        window.orientationchange = checkScreenSize; // Kiểm tra hướng màn hình
    </script>
    <div class="container">
        <h1>Forum</h1>

        <?php if (!isset($_SESSION['username'])): ?>
            <!-- Hiển thị form nếu chưa đăng nhập -->
            <form id="login-form" method="post" action="index.php" style="display: block;">
                <h2>Đăng nhập</h2>
                <input type="text" name="username" placeholder="Tên đăng nhập" required>
                <input type="password" name="password" placeholder="Mật khẩu" required>
                <button type="submit" name="login">Đăng nhập</button>
                <p>Chưa có tài khoản? <span class="toggle-link" onclick="toggleForms()">Đăng ký</span></p>
            </form>
<form id="register-form" method="post" action="index.php" style="display: none;">
    <h2>Đăng ký</h2>
    <input type="text" name="username" placeholder="Tên đăng nhập" required>
    <input type="password" name="password" placeholder="Mật khẩu" required 
           minlength="6" maxlength="30" 
           pattern="^[a-zA-Z0-9]{6,30}$" 
           title="Mật khẩu phải từ 6 đến 30 ký tự, chỉ chứa chữ cái và số, không có ký tự đặc biệt hay chữ có dấu.">
    <input type="password" name="confirm_password" placeholder="Nhập lại mật khẩu" required>
    <button type="submit" name="register">Đăng ký</button>
    <p>Đã có tài khoản? <span class="toggle-link" onclick="toggleForms()">Đăng nhập</span></p>
 <?php if (isset($_SESSION['error'])): ?>
        <div class="error"><?php echo $_SESSION['error']; ?></div> <!-- Hiển thị lỗi -->
        <?php unset($_SESSION['error']); ?> <!-- Xóa thông báo lỗi -->
    <?php endif; ?>
    <?php if (isset($_SESSION['success'])): ?>
        <div class="success"><?php echo $_SESSION['success']; ?></div> <!-- Hiển thị thành công -->
        <?php unset($_SESSION['success']); ?> <!-- Xóa thông báo thành công -->
    <?php endif; ?>
              </form>

            <?php if (isset($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            <?php if (isset($success)): ?>
                <div class="success"><?php echo $success; ?></div>
            <?php endif; ?>
        <?php else: ?>
            <!-- Hiển thị form đăng bài nếu đã đăng nhập -->
         <form method="post" action="index.php" enctype="multipart/form-data">
                <h2>Đăng bài viết</h2>
                <textarea name="content" placeholder="Nội dung bài viết (Lưu ý : Chỉ khi không nhập gì vào form thì post người khác mới cập nhật.)" required></textarea>
                <input type="text" name="description" placeholder="Mô tả ngắn" required>
                <input type="file" name="image">
                <button type="submit" name="post">Đăng bài</button>
            </form>
 <a href="index.php?logout=true">
        <button class="logout-button">Đăng xuất</button>
    </a>
    
   <h2>Các bài viết</h2>
            <?php if ($posts->num_rows > 0): ?>
                <?php while ($post = $posts->fetch_assoc()): ?>
                    <div class="post">
                        <h3><?php echo htmlspecialchars($post['content']); ?></h3>
                        <p><?php echo htmlspecialchars($post['description']); ?></p>
                        <?php if ($post['image']): ?>
                            <img src="uploads/<?php echo htmlspecialchars($post['image']); ?>" alt="Image" style="max-width: 100%; height: auto;">
                        <?php endif; ?>
                        <small>Đăng bởi: <?php echo htmlspecialchars($post['username']); ?> vào <?php echo $post['created_at']; ?></small>
                    <?php if ($post['username'] == $_SESSION['username']): ?>
    <form method="get" action="index.php" style="display:inline;" onsubmit="return confirm('Bạn có chắc chắn muốn xóa bài viết này không?');">
        <input type="hidden" name="delete" value="<?php echo $post['id']; ?>">
        <button type="submit" class="delete-button">Xóa bài viết</button>
    </form>
<?php endif; ?>

                        <form method="post" action="index.php">
                            <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                            <textarea name="content" placeholder="Bình luận" required></textarea>
                            <button type="submit" name="comment">Gửi bình luận</button>
                        </form>
<h4>Bình luận:</h4>
<?php
$post_id = $post['id'];
$comments = $conn->query("SELECT * FROM comments WHERE post_id = $post_id ORDER BY created_at DESC");
if ($comments->num_rows > 0):
    while ($comment = $comments->fetch_assoc()):
?>
        <div class="comment">
            <strong><?php echo htmlspecialchars($comment['username']); ?></strong>: 
            <span><?php echo $comment['content']; // Không dùng htmlspecialchars ?></span>
            <?php if ($comment['username'] == $_SESSION['username']): ?>
                <a href="index.php?delete_comment=<?php echo $comment['id']; ?>">Xóa bình luận</a>
            <?php endif; ?>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p class="no-posts">Chưa có bình luận nào.</p>
<?php endif; ?>                                        </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="no-posts">Chưa có bài viết nào.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>