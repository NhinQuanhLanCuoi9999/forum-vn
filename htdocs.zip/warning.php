<?php
session_start();
include('config.php');

// Kiểm tra nếu người dùng đã đăng nhập
if (!isset($_SESSION['username'])) {
    header("Location: index.php"); // Chuyển hướng nếu không đăng nhập
    exit();
}

// Kiểm tra thông tin cấm từ cơ sở dữ liệu
$username = $_SESSION['username'];
$ip = $_SERVER['REMOTE_ADDR'];

$stmt = $conn->prepare("SELECT * FROM bans WHERE username = ? OR ip_address = ?");
$stmt->bind_param("ss", $username, $ip);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: index.php"); // Chuyển hướng nếu không bị cấm
    exit();
}

// Dọn dẹp hàng cấm đã hết hạn
$stmt = $conn->prepare("DELETE FROM bans WHERE ban_end IS NOT NULL AND ban_end < NOW()");
$stmt->execute();

// Lấy thông tin cấm
$ban = $result->fetch_assoc();
$reason = $ban['reason'];
$ban_end = $ban['ban_end'];

$ban_end_date = strtotime($ban_end);
$current_date = time();
$diff_years = ($ban_end_date - $current_date) / (60 * 60 * 24 * 365); // Tính số năm còn lại

if ($ban_end === null || $diff_years > 50) {
    $ban_end_display = '<strong style="color: red; font-weight: bold;">Vĩnh viễn</strong>';
} else {
    $ban_end_display = date('d-m-Y H:i:s', $ban_end_date);
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cấm Truy Cập</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            color: #343a40;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 100px auto;
            padding: 20px;
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #dc3545;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            line-height: 1.5;
        }
        .warning {
            background-color: #ffeeba;
            border: 1px solid #ffeeba;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }
        .button {
            display: inline-block;
            padding: 10px 15px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
            text-align: center;
        }
        .button:hover {
            background-color: #0056b3;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Cấm Truy Cập</h1>
        <div class="warning">
            <p>Bạn đã bị cấm truy cập vào trang web này.</p>
            <p><strong>Lý do cấm:</strong> <?php echo htmlspecialchars($reason); ?></p>
            <p><strong>Thời gian cấm đến:</strong> <?php echo $ban_end_display; ?></p>
        </div>
        <div class="footer">
            <p>&copy; 2024 Bảo lưu mọi quyền.</p>
        </div>
    </div>
</body>
</html>
