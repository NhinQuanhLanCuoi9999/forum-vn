// Hàm ghi log
function logAction($action) {
    $ip = $_SERVER['REMOTE_ADDR'];
    $username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Khách';
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] - IP: $ip - Người dùng: $username - Hành động: $action\n";
// Hàm định dạng nội dung
function formatText($text) {
    // Định dạng chữ in đậm
    $text = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $text); // **text**
// Đăng ký
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        echo json_encode(['error' => "Hai mật khẩu không trùng khớp!"]);
        exit();
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $checkUser = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $checkUser->bind_param("s", $username);
        $checkUser->execute();
        $result = $checkUser->get_result();

        if ($result->num_rows > 0) {
            echo json_encode(['error' => "Tài khoản đã tồn tại!"]);
        } else {
            $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $hashed_password);
            $stmt->execute();
            logAction("Đăng ký tài khoản: $username");
            echo json_encode(['success' => "Đăng ký thành công!"]);
        }
    }
    exit();
}

// Đăng nhập
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $username;
            setcookie("username", $username, time() + (30 * 24 * 60 * 60), "/");
            logAction("Đăng nhập thành công: $username");
            echo json_encode(['success' => "Đăng nhập thành công!"]);
        } else {
            echo json_encode(['error' => "Mật khẩu không chính xác!"]);
        }
    } else {
        echo json_encode(['error' => "Tài khoản không tồn tại!"]);
    }
    exit();
}

// Đăng bài
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['post'])) {
    $content = $_POST['content'];
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];

    if ($image) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($image);
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
    }

    $stmt = $conn->prepare("INSERT INTO posts (content, description, image, username) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $content, $description, $image, $_SESSION['username']);
    $stmt->execute();
    logAction("Đăng bài mới của người dùng: {$_SESSION['username']}");
    echo json_encode(['success' => "Đăng bài thành công!"]);
    exit();
}
?>